// Definición de niveles.
// Coordenadas: el suelo tiene su parte superior en y = 332.
//   - Bloques "fila baja": y = 232 (se pueden golpear desde el suelo y caminar por debajo)
//   - Bloques "fila alta": y = 136 (se alcanzan saltando desde la fila baja)
// Patrón de bloques: 'B' = ladrillo, '?' = piedra rúnica (da moneda al golpearla desde abajo), ' ' = hueco
//   Trampas de bloque (cada una tiene su pista sutil: ver senales.js):
//   'E' = parece piedra rúnica pero suelta un enemigo
//   'C' = ladrillo que cae cuando pasas por debajo
//   'H' = bloque invisible (aparece al golpearlo desde abajo; ideal en el borde de un hueco)
//   'F' = ladrillo falso, no tiene piso
// falsos: [xInicio, xFin] suelo que se derrumba al pisarlo (tiene lava debajo)
// pinchos: [x, cantidad, oculto] (los ocultos salen del suelo cuando te acercas)
// bolas: [x, cadaCuantosMs] bolas de fuego que saltan desde la lava
// emboscadas: [xAviso, [x de cada enemigo]] al pasar por xAviso caen enemigos del cielo
// carcajes: [x, y] dan +5 flechas
// corazones: [x, y] recuperan una vida   cristales: [x, y] valen 500 puntos (suelen estar en sitios peligrosos)
// mezcla: tipos de enemigos que caminan en el nivel (se van turnando); ver enemigos.js
// plantas: x de plantas disfrazadas de arbusto (¡no las pises, tienen espinas!)
// espiritus: [x, y] espíritus de fuego que vuelan y disparan
//
// Más trampas sorpresa (ver sorpresas.js):
// carteles: [x, y, texto] letreros burlones (suelen mentir)
// monedasTrampa: [x, y] parecen monedas, pero al tomarlas cae un enemigo del cielo
// rocas: x  una roca/estalactita se desprende del techo cuando pasas por debajo
// estatuasFalsas: x  parece un punto de control, pero se convierte en esqueleto
// mordedoras: [x, y] plataforma que tiembla, se pone roja y muerde si no te bajas rápido
// banderasFalsas: x  una meta falsa: el faro sale huyendo y suelta enemigos
// persecuciones: x  al pasar por ahí aparece un zombie gigante que te persigue
// suelo / lava: rangos [xInicio, xFin]
// enemigos: x (aparece en el suelo) o [x, y]
// goteros: [x, cadaCuantosMs] (gotas de lava que caen del techo)
// moviles: [x, y, eje 'x'|'y', recorrido, velocidad]  (eje 'y' = ascensor: sube desde y hasta y - recorrido)
// plataformas: [x, arriba, ancho]  plataformas flotantes de roca a cualquier altura
// muros: [x, arriba, ancho]  columna de roca maciza desde el suelo (corta el paso: se sube por encima)
// antorchas: [x, y]  antorchas en la pared
// techos: [x0, x1, abajo]  túnel: roca maciza desde arriba hasta 'abajo' (ver tramos.js)
// runas: [x, y, [losas]]  piedra rúnica: al golpearla desde abajo aparecen las losas [x, arriba, ancho]
// inicio: [x, y]  dónde aparece el jugador al empezar el nivel (por defecto, en el suelo al inicio)
// alto: px que el nivel crece hacia ARRIBA (torres, puentes colgantes); la cámara sube con el jugador.
//   Las secciones altas usan y negativa. Las pruebas comprueban que se llegue a todo (alcance.js)
// escaleras: [x, altura en bloques]
// meta: x de la bandera
// checkpoints: x donde reaparece Gesi si muere después de pasar por ahí
// velEnemigos: velocidad de los enemigos (sube en cada nivel)
// Una gota de lava golpea en x + 31 respecto a su gotero: los goteros se ponen
// sobre huecos o suelo, nunca sobre una plataforma en la que haya que pararse.

import {
    colocar, extender, tramoLlano, tramoTunel, tramoAscensorMirador, tramoCornisaSecreta,
    tramoTorre, tramoPuentesAltos, tramoDobleCamino, tramoAbismoRunico, tramoRamas, tramoArbolAnciano,
    zonaSalida, zonaPuente, zonaTunel, zonaAtajo, zonaSueloMentiroso, zonaPersecucion, zonaLlegada,
} from "./tramos.js"

export const SUELO_Y = 332;

// fila de monedas
const fila = (x, y, n, sep = 32) => Array.from({ length: n }, (_, i) => [x + i * sep, y]);

// arco de monedas sobre un hueco
const arco = (x, y) => [[x, y + 20], [x + 30, y], [x + 60, y + 20]];

export const NIVELES = [
    {
        nombre: 'El Bosque de Gesi',
        ancho: 5200,
        nubes: true,
        fondo: 'montanas', // montañas en silueta con árboles secos (en vez del paisaje)
        velEnemigos: 40,
        checkpoints: [2400],
        mezcla: ['zombie1', 'zombie2', 'alien_green', 'zombie3', 'esqueleto'],
        plantas: [2750, 4150],
        // la primera parte (hasta x≈2300) está hecha a mano en construirNivel1()
        suelo: [[2300, 3000], [3130, 3480], [3600, 3700], [3840, 5200]],
        lava: [[3000, 3130], [3700, 3840]],
        falsos: [[3480, 3600]],
        bloques: [
            [2450, 232, 'B?BEB'],
            [2700, 136, 'BBFB'],
            [2980, 232, 'H'],
            [3300, 232, '?CC?'],
            [3480, 136, 'BBBB'],
            [3690, 232, 'H'],
            [4050, 232, 'BE?B'],
        ],
        pinchos: [[4260, 2, true]],
        emboscadas: [[3900, [4100, 4300]]],
        carcajes: [[2550, 300]],
        corazones: [[4500, 160]],
        cristales: [[3065, 185]],
        carteles: [[2965, 175, '¡SALTA AQUÍ!'], [3440, 255, 'ATAJO →']],
        monedasTrampa: [[2850, 300], [4030, 300]],
        rocas: [4390],
        escaleras: [[4450, 4]],
        enemigos: [2600, 2900, 3350, 3550, 4000, 4200, 4350],
        monedas: [
            [280, 312],
            [2110, 150],
            ...fila(2330, 300, 3),
            ...fila(2716, 100, 4),
            ...arco(3035, 230),
            ...fila(3496, 100, 4),
            ...arco(3740, 230),
            ...fila(3900, 300, 4),
            ...fila(4066, 190, 4),
        ],
        goteros: [[3739, 2200]],
        meta: 4800,
    },
    {
        nombre: 'La Cueva de Lava',
        ancho: 6000,
        cueva: true,
        tinte: 0x8a4a3a,
        velEnemigos: 50,
        checkpoints: [3150],
        mezcla: ['esqueleto', 'zombie2', 'alien_blue', 'zombie3', 'esqueleto', 'alien_gray', 'zombie1'],
        plantas: [1250, 5000],
        espiritus: [[1440, 190], [2840, 170], [4560, 190]],
        suelo: [[0, 700], [850, 1400], [1540, 1740], [1950, 2600], [3100, 3800], [3950, 4500], [4650, 6000]],
        falsos: [[1740, 1800]],
        bolas: [[760, 2500], [1455, 2200], [2842, 2300], [3860, 2000]],
        pinchos: [[4380, 2, true]],
        emboscadas: [[3300, [3500, 3650]]],
        carcajes: [[1200, 290], [3200, 270]],
        corazones: [[2398, 55]],
        cristales: [[2842, 200]],
        carteles: [[2860, 150, '¡ATAJO SEGURO!'], [2200, 110, 'NO MIRES ARRIBA']],
        monedasTrampa: [[1650, 300], [4796, 300]],
        rocas: [520, 5150],
        estatuasFalsas: [1080],
        mordedoras: [[775, 285], [3875, 280]],
        lava: [[700, 850], [1400, 1540], [1800, 1950], [2600, 3100], [3800, 3950], [4500, 4650]],
        bloques: [
            [300, 232, 'B?B'],
            [950, 232, 'BBBBB'],
            [1610, 232, '?'],
            [2150, 232, 'B?B?B'],
            [2350, 136, 'BBB'],
            [2590, 232, 'H'],
            [2720, 280, 'BB'], // islas sobre la lava
            [2900, 280, 'FB'], // ¡la mitad izquierda es falsa!
            [3300, 232, 'BC?CB'],
            [4050, 232, '?B?'],
            [4800, 232, 'EB?'],
            [4950, 136, 'BBB'],
        ],
        escaleras: [[4250, 3], [5300, 4]],
        enemigos: [450, 600, [1000, 200], 1150, 1300, 2100, 2250, 2450, 3250, 3400, 3550, 3700, 4100, 4900, 5050, 5200],
        monedas: [
            ...fila(200, 300, 4),
            ...arco(745, 230),
            ...fila(966, 190, 5),
            ...arco(1440, 230),
            ...arco(1845, 230),
            ...fila(2366, 100, 3),
            ...fila(2736, 245, 2),
            ...fila(2916, 245, 2),
            ...fila(3150, 300, 4),
            ...fila(4966, 100, 3),
            ...fila(4700, 300, 3),
        ],
        goteros: [[744, 2000], [1200, 1800], [1844, 1900], [2811, 2000], [3500, 1800], [4544, 1900], [5150, 1700]],
        meta: 5650,
    },
    {
        nombre: 'Puentes sobre la Lava',
        ancho: 6300,
        // ruta alta sobre el lago de lava (2800-3400): un ascensor sube a los puentes colgantes y al
        // final se baja de un salto a la otra orilla. La ruta de abajo (plataforma móvil) sigue ahí.
        alto: 450,
        plataformas: [[2720, -96, 150], [2900, -150, 120], [3300, -150, 140]],
        nubes: true,
        tinte: 0xffb38a,
        velEnemigos: 55,
        checkpoints: [2350, 3450],
        mezcla: ['alien_green', 'alien_blue', 'esqueleto', 'zombie3'],
        plantas: [1550, 2550],
        espiritus: [[850, 140], [2000, 150], [4350, 150], [3150, -60]],
        suelo: [[0, 600], [1100, 1700], [2300, 2700], [3400, 4000], [4700, 6300]],
        falsos: [[2700, 2800]],
        bolas: [[1000, 2400], [2000, 2100], [3330, 2200], [4300, 2000]],
        pinchos: [[3820, 2, true], [1450, 1, true]],
        emboscadas: [[5000, [5150, 5250]]],
        carcajes: [[1150, 290], [4750, 290]],
        corazones: [[5358, 35]],
        cristales: [[3700, 60], [3150, -240]], // el segundo, premio de la ruta alta
        carteles: [[590, 185, 'SALTA AQUÍ ↓'], [5180, 120, '¡META!'], [1640, 200, 'TODO BIEN :)']],
        monedasTrampa: [[282, 300], [1120, 300], [4780, 300]],
        rocas: [1460, 3530, 4880],
        estatuasFalsas: [4760],
        mordedoras: [[1400, 316], [5480, 316]],
        banderasFalsas: [5180],
        persecuciones: [3470],
        lava: [[600, 1100], [1700, 2300], [2800, 3400], [4000, 4700]],
        moviles: [
            [694, 300, 'x', 312, 70],
            [1794, 300, 'x', 412, 90],
            [2894, 300, 'x', 150, 60],
            [2640, 316, 'y', 396, 55], // ascensor a la ruta alta (descansa en el suelo)
            [3090, -174, 'x', 120, 60], // puente móvil en lo alto
            [4094, 290, 'x', 250, 90],
            [5350, 236, 'y', 110, 45], // ascensor de bonus
        ],
        bloques: [
            [590, 232, 'H'],
            [1250, 232, 'B?B'],
            [1450, 232, 'B?B?B'], // fila sobre la isla del medio: puede esconder trampas de bloque
            [1290, 136, '?B?'],
            [1690, 232, 'H'],
            [3990, 232, 'H'],
            [2330, 232, '?BEB?'], // (deja sitio para saltar al ascensor de la ruta alta)
            [3140, 280, 'BBBB'],
            [3480, 232, 'BB'],
            [3600, 136, 'BBBBBB'],
            [3720, 232, 'B?B?'],
            [3880, 232, '?'],
            [4440, 280, 'BBBB'],
            [5000, 232, 'B?C?B'],
        ],
        escaleras: [[5600, 4]],
        enemigos: [450, 1180, 1300, 1500, 1650, 2450, 2500, 2650, 3600, 3700, 3800, 3900, 4850, 4900, 5050, 5200, 5250, 5450],
        monedas: [
            ...fila(150, 300, 4),
            ...fila(780, 230, 6),
            ...fila(1466, 190, 5),
            ...fila(1900, 230, 8),
            ...fila(3156, 245, 4),
            ...fila(2735, -130, 4), // ruta alta
            ...fila(2915, -185, 3),
            ...fila(3315, -185, 3),
            ...fila(3616, 100, 6),
            ...fila(4180, 220, 5),
            ...fila(5310, 75, 4),
        ],
        goteros: [[2760, 1600], [3550, 1500], [4900, 1500]], // (el primero, lejos del ascensor)
        meta: 5900,
    },
    {
        nombre: 'La Fortaleza',
        ancho: 6900,
        // torre (2850-3500): un muro de roca de casi 600 px corta el paso; se sube en zigzag por la
        // izquierda, se cruza por arriba (con premio) y se baja de un salto por la derecha.
        // El apagón de la Fortaleza ocurre justo al empezar a subir (ver regiones.js)
        alto: 650,
        muros: [[3240, -260, 90]],
        plataformas: [
            [2890, 236, 120], [3100, 140, 130],
            [2890, 44, 120], [3100, -52, 130],
            [2890, -148, 120], [3100, -244, 130],
        ],
        antorchas: [[3226, 200], [3226, 10], [3226, -180]],
        cueva: true,
        tinte: 0x7a5aa8,
        velEnemigos: 65,
        checkpoints: [1950, 2880, 4250],
        mezcla: ['esqueleto', 'alien_armor', 'alien_red', 'zombie1', 'alien_predator_mask'],
        plantas: [1000, 2100, 4700, 5850],
        espiritus: [[1600, 140], [3850, 150], [5075, 180]],
        suelo: [[0, 500], [640, 1300], [1900, 2400], [2600, 2700], [2850, 3600], [4200, 5000], [5150, 6900]], // (2850-3600: torre y aterrizaje amplio al bajar)
        falsos: [[2550, 2600]],
        bolas: [[570, 1800], [1600, 2200], [2475, 1700], [2775, 1700], [3680, 2000], [5075, 1700]],
        pinchos: [[5450, 2, true], [6050, 1, true]],
        emboscadas: [[4300, [4500, 4650, 4800]], [5600, [5800, 5950]]],
        carcajes: [[700, 290], [4250, 280]],
        corazones: [[3285, -300]], // en la cima de la torre
        cristales: [[2475, 200], [3285, -340]],
        carteles: [[480, 180, 'SALTA AQUÍ'], [2250, 150, 'PUNTO DE CONTROL →'], [5700, 120, '¡LLEGASTE!']],
        monedasTrampa: [[1050, 300], [3300, 300], [4900, 300]],
        rocas: [720, 2200, 4550],
        estatuasFalsas: [2300, 5250],
        mordedoras: [[2475, 280], [5075, 280]],
        banderasFalsas: [5720],
        persecuciones: [2900, 4300],
        lava: [[500, 640], [1300, 1900], [2400, 2550], [2700, 2850], [3600, 4200], [5000, 5150]],
        moviles: [
            [1394, 300, 'x', 412, 100],
            [3810, 250, 'x', 230, 80],
        ],
        bloques: [
            [490, 232, 'H'],
            [850, 232, '?BEB?'],
            [2000, 232, 'B?B'],
            [3590, 232, 'H'],
            [3640, 280, 'BBB'],
            [4400, 232, 'BC?C?CB'],
            [5500, 232, 'BCCB'],
        ],
        escaleras: [[5300, 3], [6100, 5]],
        enemigos: [350, 800, 950, 1100, 1250, 2050, 2200, 2600, 3450,
            4350, 4500, 4650, 4800, 4950, 5600, 5750, 5900, 6000],
        monedas: [
            ...arco(540, 230),
            ...fila(1450, 230, 10),
            ...arco(2445, 230),
            ...arco(2745, 230),
            ...fila(3115, 105, 3), // por la torre
            ...fila(3115, -87, 3),
            ...fila(3115, -279, 3),
            ...fila(3636, 245, 3),
            ...fila(3850, 200, 5),
            ...fila(5516, 190, 4),
            ...fila(6200, 100, 3),
        ],
        goteros: [[539, 1500], [1600, 2000], [2444, 1400], [2744, 1400], [3950, 2000], [4600, 1400], [5044, 1400]],
        meta: 6450,
    },
    // el Volcán empieza arriba, en el borde del cráter, y se baja por cornisas sobre la lava;
    // tiene una torre y el primer abismo rúnico (golpear la runa crea el puente)
    generarNivel({
        nombre: 'El Volcán', semilla: 7, dificultad: 0.75, tramos: 12, cueva: true, tinte: 0xb8503a,
        mezcla: ['esqueleto', 'zombie1', 'alien_dark_gray', 'zombie3', 'alien_gray', 'esqueleto'],
        bajadaInicial: true, especiales: ['runa', 'tunel', 'torre4'],
    }),
    // las Nubes combinan todo lo aprendido: puentes altos, abismos rúnicos y una torre alta
    generarNivel({
        nombre: 'El Reino de las Nubes', semilla: 21, dificultad: 1, tramos: 16, nubes: true, tinte: 0x9fb8ff,
        mezcla: ['alien_green', 'alien_blue', 'alien_red', 'alien_predator_mask', 'alien_armor', 'esqueleto'],
        especiales: ['puentesAltos', 'tunel', 'runa', 'torre6', 'dobleCamino', 'runa', 'tunel'],
    }),
    nivelRuinas(),
];

// ---------- Niveles más largos a medida que se avanza ----------
// Los niveles hechos a mano se alargan con piezas (tramos.js) colocadas justo antes de la arena
// del jefe: cada nivel suma lo nuevo que enseña (túneles, ascensores, doble camino, torres).
// En x hay suelo firme; todo lo que estaba a la derecha (arena, meta) se corre.
// Bosque: primer túnel, primer ascensor (corto y opcional), una cornisa secreta, ramas que se
// doblan sobre la lava y, antes del jefe, el momento ¡wow!: el Árbol Anciano
extender(NIVELES[0], 3850, [
    tramoLlano(300), // (antes de un túnel siempre hay llano: saltar un foso hacia su techo sería injusto)
    tramoTunel(700, { enemigos: 1 }), tramoLlano(300), tramoAscensorMirador(), tramoLlano(250, { enemigos: 1 }),
    tramoCornisaSecreta(), tramoRamas(), tramoArbolAnciano(),
]);
extender(NIVELES[1], 4660, [ // Cueva: doble camino sobre la lava y un túnel largo
    tramoLlano(200), tramoDobleCamino(), tramoLlano(400, { enemigos: 1 }), tramoTunel(900),
    tramoLlano(300), tramoCornisaSecreta(),
]);
extender(NIVELES[2], 4710, [ // Puentes: túnel, una torre y otro doble camino
    tramoLlano(300), tramoTunel(600), tramoLlano(300, { enemigos: 1 }), tramoTorre(4), tramoLlano(400),
    tramoDobleCamino(), tramoLlano(300),
]);
extender(NIVELES[3], 5160, [ // Fortaleza: túneles, doble camino y una torre alta
    tramoLlano(300), tramoTunel(900), tramoLlano(700, { enemigos: 2 }), tramoDobleCamino(), tramoLlano(400),
    tramoTorre(6), tramoLlano(400, { enemigos: 1 }), tramoTunel(600), tramoLlano(300),
]);

// Generador de niveles grandes a partir de "tramos" que siempre se pueden pasar.
// Nivel 7 · Las Ruinas del Abismo: el Rey Troll huye de las Nubes al abismo y ahí espera, en su
// último trono. Es la pista de carrera de las Ruinas (las 7 zonas de tramos.js) alargada con piezas
// conocidas. Trampas puestas a mano (fija: no pasa por aleatorizarNivel, ver prepararNivelFijo en
// azar.js); los mecanismos propios (aplastadores, portal, muro que persigue) están en abismo.js.
// Ritmo:
//   1. Introducción: la salida y su bifurcación opcional (arriba premio, abajo directo)
//   2. Desafío: el Puente de la Muerte (tablones frágiles) y el Túnel Maldito (aplastadores)
//   3. Descanso: llano, una torre con cristal y el abismo rúnico
//   4. Momento ¡wow!: el Atajo Maldito (senda segura arriba / atajo con portal y géiser abajo)
//   5. Desafío fuerte: suelo mentiroso, otro puente, túnel y la Persecución del muro del abismo
//   6. Antesala tranquila y el trono del Rey Troll
function nivelRuinas() {
    const n = {
        nombre: 'Las Ruinas del Abismo', ancho: 0, meta: 0, fija: true, abismo: true,
        tinte: 0xa58a9a, velEnemigos: 80,
        mezcla: ['esqueleto', 'zombie3', 'alien_dark_gray', 'zombie2', 'alien_armor', 'esqueleto'],
        suelo: [], checkpoints: [], carteles: [],
    };
    const piezas = [
        zonaSalida(), zonaPuente(), zonaTunel(),
        tramoLlano(400, { enemigos: 1 }), tramoTorre(5), tramoAbismoRunico(), tramoLlano(300),
        zonaAtajo(), zonaSueloMentiroso(), tramoDobleCamino(), tramoLlano(500, { enemigos: 2 }),
        zonaPuente(), tramoCornisaSecreta(), tramoAscensorMirador(), tramoTunel(800), tramoLlano(400),
        zonaPersecucion(), zonaLlegada(), tramoLlano(800),
    ];
    const ancho = piezas.reduce((s, t) => s + t.ancho, 0);
    const arena = ancho - 300 - 1500; // (la arena del jefe y su antesala: sin puntos de control dentro)
    let x = 0;
    piezas.forEach(t => {
        colocar(n, t, x);
        if (x > 0 && t.ancho >= 600 && x + 60 < arena) n.checkpoints.push(x + 60);
        x += t.ancho;
    });
    n.ancho = ancho;
    n.meta = ancho - 300;
    return n;
}

// dificultad va de 0 (fácil) a 1 (difícil): huecos más anchos, más enemigos,
// gotas más seguidas y plataformas más rápidas.
function azar(semilla) {
    let a = semilla;
    return () => {
        a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

// especiales: tramos con altura que se reparten a lo largo del nivel ('torre4', 'torre6', 'puentesAltos', 'runa')
// bajadaInicial: el nivel empieza arriba y se baja por cornisas sobre la lava
function generarNivel({ nombre, semilla, dificultad: d, tramos, cueva = false, nubes = false, tinte, mezcla, especiales = [], bajadaInicial = false }) {
    const r = azar(semilla);
    const entre = (a, b) => Math.round(a + r() * (b - a));
    const n = {
        nombre, cueva, nubes, tinte, mezcla, plantas: [], espiritus: [],
        velEnemigos: Math.round(50 + 30 * d),
        suelo: [], lava: [], bloques: [], escaleras: [], enemigos: [],
        monedas: [], goteros: [], moviles: [], checkpoints: [],
        falsos: [], pinchos: [], bolas: [], emboscadas: [], carcajes: [], corazones: [], cristales: [],
        carteles: [], monedasTrampa: [], rocas: [], estatuasFalsas: [], mordedoras: [], banderasFalsas: [], persecuciones: [],
        plataformas: [], muros: [], antorchas: [], runas: [], alto: 0,
    };
    const BURLAS_CARTEL = ['¡SALTA AQUÍ!', 'ATAJO →', 'TODO BIEN :)', 'NO HAY TRAMPAS', 'CONFÍA', '¡CASI LLEGAS!'];
    const intervaloGota = () => Math.round(2200 - 800 * d);
    let x = 0;

    const llano = (largo, { enemigos = true, bloques = true, trampas = true } = {}) => {
        // suelo falso en medio del llano (siempre se puede saltar por encima)
        if (trampas && largo >= 600 && r() < 0.35 * d) {
            const a = entre(250, largo - 260);
            n.suelo.push([x, x + a], [x + a + 96, x + largo]);
            n.falsos.push([x + a, x + a + 96]);
        } else {
            n.suelo.push([x, x + largo]);
        }
        if (trampas && largo >= 500) {
            if (r() < 0.4 + 0.4 * d) n.pinchos.push([x + largo - 120, d > 0.6 ? 2 : 1, true]);
            if (r() < 0.4 + 0.4 * d) n.monedasTrampa.push([x + entre(160, largo - 160), 300]);
            if (r() < 0.3 + 0.4 * d) n.rocas.push(x + entre(200, largo - 200));
            if (r() < 0.25 * d) n.mordedoras.push([x + Math.round(largo / 2), 316]);
            if (r() < 0.3) n.carteles.push([x + entre(120, largo - 120), 150, BURLAS_CARTEL[entre(0, BURLAS_CARTEL.length - 1)]]);
            if (r() < 0.5 * d) n.emboscadas.push([x + 100, [x + 300, x + 450]]);
            if (r() < 0.25) n.carcajes.push([x + Math.round(largo / 2), 290]);
            if (r() < 0.3 + 0.3 * d) n.plantas.push(x + entre(220, largo - 160));
        }
        if (bloques && largo >= 500 && r() < 0.75) {
            const patrones = ['B?B', '?B?B?', 'BB?BB', '???', 'B??B', 'BEB', '?C?', 'C?C', 'E??', 'BCCB'];
            const p = patrones[entre(0, patrones.length - 1)];
            const bx = x + entre(150, largo - 350);
            n.bloques.push([bx, 232, p]);
            n.monedas.push(...fila(bx + 16, 190, p.length));
            if (r() < 0.5) {
                const ax = bx + p.length * 32 + 50;
                n.bloques.push([ax, 136, 'BBB']);
                n.monedas.push(...fila(ax + 16, 100, 3));
            }
        } else {
            n.monedas.push(...fila(x + 120, 300, 4));
        }
        if (enemigos) {
            const cuantos = 1 + Math.floor(r() * (1 + 2.5 * d));
            const paso = (largo - 250) / cuantos;
            for (let i = 0; i < cuantos; i++) n.enemigos.push(Math.round(x + 150 + i * paso + r() * paso * 0.5));
        }
        x += largo;
    };

    const hueco = () => {
        const g = entre(100, 110 + 40 * d);
        n.lava.push([x, x + g]);
        n.monedas.push(...arco(Math.round(x + g / 2 - 30), 230));
        if (r() < 0.25) n.cristales.push([Math.round(x + g / 2), 185]); // cristal sobre la lava
        if (r() < 0.6 * d) {
            n.bloques.push([x - 12, 232, 'H']); // bloque invisible en el borde
            if (r() < 0.5) n.carteles.push([x - 30, 175, '¡SALTA AQUÍ!']);
        }
        // plataforma tentadora en medio de la lava (el hueco se puede saltar sin ella)
        if (g >= 120 && r() < 0.4 * d) n.mordedoras.push([Math.round(x + g / 2), 284]);
        if (r() < 0.5 * d) n.bolas.push([Math.round(x + g / 2), entre(1800, 2600)]);
        else if (r() < 0.3 * d) n.espiritus.push([Math.round(x + g / 2), 170]);
        if (r() < 0.3 + 0.6 * d) n.goteros.push([Math.round(x + g / 2 - 31), intervaloGota()]);
        x += g;
    };

    const islas = () => {
        const inicio = x;
        const cuantas = d > 0.5 ? 3 : 2;
        x += 115;
        for (let i = 0; i < cuantas; i++) {
            n.bloques.push([x, 280, 'BBB']);
            n.monedas.push(...fila(x + 16, 245, 3));
            x += 96;
            if (i < cuantas - 1 && r() < d) {
                if (r() < 0.5) n.goteros.push([x + 57 - 31, intervaloGota()]);
                else n.bolas.push([x + 57, entre(1800, 2600)]);
            }
            x += 115;
        }
        n.lava.push([inicio, x]);
    };

    const puente = () => {
        const ancho = entre(380, 420 + 200 * d);
        n.lava.push([x, x + ancho]);
        n.moviles.push([x + 94, 300, 'x', ancho - 188, Math.round(70 + 40 * d)]);
        if (r() < d) n.espiritus.push([x + Math.round(ancho / 2), 140]);
        n.monedas.push(...fila(x + 100, 230, Math.floor((ancho - 200) / 40), 40));
        x += ancho;
    };

    const escalera = () => {
        const inicio = x;
        llano(520, { enemigos: false, bloques: false, trampas: false });
        n.escaleras.push([inicio + 200, d > 0.5 ? 4 : 3]);
    };

    // tramos especiales: piezas compartidas (tramos.js), las mismas que alargan los niveles hechos a mano
    const especial = t => { colocar(n, t, x); x += t.ancho; };
    const TRAMOS_ESPECIALES = {
        torre4: () => especial(tramoTorre(4)), torre6: () => especial(tramoTorre(6)),
        puentesAltos: () => especial(tramoPuentesAltos()), dobleCamino: () => especial(tramoDobleCamino()),
        runa: () => especial(tramoAbismoRunico()), tunel: () => especial(tramoTunel(800)),
    };
    // en qué tramo va cada especial: repartidos a lo largo del nivel
    const posEspecial = new Map(especiales.map((e, k) => [Math.floor(((k + 1) * tramos) / (especiales.length + 1)), e]));

    // bajada inicial: se aparece en el borde del cráter y se baja por cornisas en zigzag sobre la lava
    if (bajadaInicial) {
        n.inicio = [60, -450]; // (el personaje cae un poco y se posa en la primera cornisa)
        n.plataformas.push([0, -300, 200], [250, -204, 120], [40, -108, 120], [250, -12, 120], [40, 84, 120], [250, 180, 120]);
        n.lava.push([0, 480]);
        n.alto = Math.max(n.alto, 520);
        x = 480;
    }

    const obstaculos = [hueco, hueco, islas, puente, escalera];
    const CHECKPOINT_CADA = 2400; // un punto de control cada ~2400 px (los niveles generados son largos)
    let ultimoCheckpoint = 0;
    const ponerCheckpoint = cx => {
        if (r() < d) n.estatuasFalsas.push(cx - 30); // una estatua falsa justo antes de la real
        n.checkpoints.push(cx);
        ultimoCheckpoint = cx;
        if (r() < d) n.persecuciones.push(cx + 60); // y después, un gigante
        n.corazones.push([cx + 50, 290]); // un corazón junto a cada punto de control
    };
    llano(700, { enemigos: false, trampas: false });
    for (let i = 0; i < tramos; i++) {
        // un tramo especial reemplaza al obstáculo al azar (el punto de control y el llano siguen igual)
        if (posEspecial.has(i)) TRAMOS_ESPECIALES[posEspecial.get(i)]();
        else obstaculos[entre(0, obstaculos.length - 1)]();
        // después del obstáculo empieza un llano: el punto de control va al comienzo
        if (x - ultimoCheckpoint >= CHECKPOINT_CADA) ponerCheckpoint(x + 60);
        llano(entre(450, 800));
        // y al final del llano también se revisa (por si el obstáculo siguiente es largo)
        // (a 120 px del final: un suelo falso del llano termina como mucho a 164 px del final)
        if (x - ultimoCheckpoint >= CHECKPOINT_CADA) ponerCheckpoint(x - 120);
    }

    // meta falsa antes de la verdadera
    llano(700, { enemigos: false, bloques: false, trampas: false });
    n.banderasFalsas.push(x - 350);
    n.carteles.push([x - 350, 120, '¡META!']);
    if (d >= 1) {
        n.persecuciones.push(x - 600);
        llano(600, { bloques: false, trampas: false }); // tramo de la arena del jefe: sin suelo falso
    }

    // final: escalera, bandera y castillo
    const fin = x;
    const altura = d > 0.6 ? 5 : 4;
    llano(1100, { enemigos: false, bloques: false, trampas: false });
    n.escaleras.push([fin + 200, altura]);
    n.meta = fin + 200 + altura * 32 + 250;
    n.ancho = x;
    return n;
}
