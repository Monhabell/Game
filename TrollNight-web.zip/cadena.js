// Modo cadena: los jugadores van atados en fila por una cadena; si uno cae, el otro siente el tirón.
// En el mismo teclado (2 jugadores, se activa en la configuración) o en línea (hasta 8, multijugador.js).
//
//   Jugador 1: flechas para moverse y saltar, ↓ para anclarse (más ESPACIO, X y C: sus poderes)
//   Jugador 2: A / D para moverse, W para saltar, S para anclarse
//
// Reglas de la cadena:
// - Solo tira cuando está tensa (más de LARGO px entre los dos); floja, cuelga con su peso.
// - Si uno queda en el aire (colgando) y el otro en el suelo, el del suelo es ARRASTRADO hacia el
//   borde... salvo que esté anclado (mantener ↓ / S en el suelo): entonces sostiene al otro.
//   Caminar en contra del tirón sube al que cuelga; el que cuelga puede columpiarse.
// - Vidas compartidas: si uno cae a la lava o lo golpean, caen los dos (es la misma vida).
// - RESCATE: si alguien cae a un foso estando atado, la cadena lo atrapa y queda colgando sobre la lava.
//   Si un compañero se ancla a tiempo (VENTANA_ANCLAR), la cadena lo sube hasta él; si nadie lo
//   sostiene, recién ahí cuenta como caída. Así un error se vuelve un rescate y no un reinicio de todos.
//   Cada pantalla rescata solo a sus jugadores; en línea se avisa a los demás para que se anclen.
//
// api: { morir(causa) } (killgesi del juego)

import { PERSONAJES, resDe } from "./personajes.js"
import { enLinea, enviarEvento, alRecibir } from "./red.js"

const SUELO_Y = 332;
const LARGO = 170;          // px de cadena
const ARRASTRE = 120;       // px/s con que el que cuelga arrastra al que está en el suelo
const CORRECCION = 0.35;    // fracción del estirón que se corrige en cada cuadro (moviendo la posición, sin empujar)
const HOLGURA_RED = 24;     // px extra de cadena con un jugador de otra pantalla (su posición llega con retraso)
const ESTIRON_MAX = 50;     // px que la cadena se puede estirar antes de corregir de golpe
const VEL_CARRERA = 220;
const VEL_DERIVA = 100;
const ESLABONES = 20;
// rescate
const Y_COLGANDO = 274;       // y del que cuelga: los pies justo sobre la lava (se muere al pasar de y = 300)
const VENTANA_ANCLAR = 1500;  // ms para que alguien se ancle después de la caída
const GRACIA_ANCLA = 600;     // ms que aguanta si el que lo sostiene se suelta un momento
const RESCATE_MAX = 6000;     // ms máximos colgando (si se traba, cuenta como caída)
const SUBE = 190;             // px/s con que la cadena sube al que cuelga

// en línea: si otro jugador quedó colgando, en esta pantalla se avisa que hay que anclarse
let escenaCadena = null;
alRecibir('evento', m => {
    if (m.tipo === 'colgando' && escenaCadena?.sys?.isActive()) escenaCadena.mostrarMensajeCorto?.('¡ALGUIEN CUELGA!\n¡ANCLATE! (↓)');
});

const enSuelo = s => s.body.blocked.down || s.body.touching.down;

export function crearCadena(scene, { x, y, api }) {
    // el compañero es otro personaje distinto al del jugador 1
    const pj = PERSONAJES.find(p => p.id !== scene.pj.id);
    const c = scene.physics.add.sprite(x - 40, y, `${pj.id}-idle`)
        .setCollideWorldBounds(true)
        .setGravityY(480)
        .setDepth(34);
    const r = resDe(pj); // héroes HD: hojas al doble, se dibujan a la mitad
    c.setScale(1 / r);
    c.setCrop(0, 57 * r, c.width, c.height - 50 * r);
    c.body.setSize(20 * r, 69 * r).setOffset(55 * r, 57 * r);
    c.pj = pj;
    c.anims.play(`${pj.id}-idle`);
    scene.compa = c;
    scene.cadenaApi = api;

    scene.teclasCompa = scene.input.keyboard.addKeys({ izq: 'A', der: 'D', salto: 'W', anclar: 'S' });

    // choca con el mundo como el jugador 1
    scene.physics.add.collider(c, scene.floor);
    scene.physics.add.collider(c, scene.moviles);
    scene.physics.add.collider(c, scene.invisibles, null, (_c, b) => b.revelado);

    // lo que lo mata (la vida es compartida: muere el equipo)
    const vivo = () => !scene.mascotaGesi.isDead;
    scene.physics.add.overlap(c, scene.lavaes, () => api.morir('caida'), vivo);
    scene.physics.add.overlap(c, scene.lavaesgota, () => api.morir(), vivo);
    scene.physics.add.overlap(c, scene.bolas, () => api.morir(), vivo);
    scene.physics.add.overlap(c, scene.enemies, (_c, e) => { if (!e.isDead) api.morir(undefined, 20, e.x); }, vivo);
    scene.physics.add.overlap(c, scene.balasEnemigas, (_c, bala) => { bala.destroy(); api.morir(); }, vivo);

    // nombre sobre la cabeza para no confundirlos
    c.etiqueta = scene.add.text(0, 0, 'J2', {
        fontFamily: '"Press Start 2P", monospace', fontSize: '7px', color: '#ffe066', stroke: '#000', strokeThickness: 3,
    }).setOrigin(0.5, 1).setDepth(35);

}

// se llama al final de update(), después de mover al jugador 1.
// Los eslabones unen una FILA de jugadores: [J1, J2] en el mismo teclado, o los de la sala en línea
// (hasta 8). Cada pantalla solo mueve a sus jugadores locales: los de otros dispositivos se mueven
// en su propia pantalla con las mismas reglas, así que el tirón se siente igual de los dos lados.
export function actualizarCadena(scene, time) {
    const a = scene.mascotaGesi, c = scene.compa?.active ? scene.compa : null;
    const quieto = a.isDead || scene.nivelTerminado || scene.cinematica;
    if (c) {
        if (quieto) c.setVelocityX(0);
        else {
            moverCompa(scene, c);
            // caer fuera del mundo (salvo que la cadena lo atrape: rescate)
            if (c.y >= 300 && !sostenerEnCadena(scene, c)) scene.cadenaApi.morir('caida');
        }
        c.etiqueta.setPosition(c.x, c.body.top - 4);
    }

    const nodos = (c ? [{ local: true, s: a }, { local: true, s: c }] : scene.cadenaRed?.() || []).map(nodo);
    if (nodos.length < 2) { scene.dibujoCadena?.clear(); return; }
    escenaCadena = scene;
    if (!quieto) {
        anclarJugador1(scene, a);
        for (let i = 0; i + 1 < nodos.length; i++) tensar(nodos[i], nodos[i + 1]);
        // los que cuelgan (después del tirón: la cadena manda sobre su movimiento)
        [a, c].forEach(s => s && actualizarColgado(scene, s, nodos));
    }
    if (!scene.dibujoCadena) scene.dibujoCadena = scene.add.graphics().setDepth(33);
    dibujar(scene.dibujoCadena, nodos, time);
}

// ---------- rescate ----------
// ¿la cadena atrapa a este jugador que cae al foso? (se llama en vez de morir por caída)
export function sostenerEnCadena(scene, s) {
    if (!hayCadena(scene) || s.rescateAgotado || scene.nivelTerminado || s.y < Y_COLGANDO) return false;
    const compañeros = scene.compa?.active ? 1 : (scene.cadenaRed?.() || []).length - 1;
    if (compañeros < 1) return false; // nadie más en la fila: no hay quién lo sostenga
    if (!s.colgando) {
        const ahora = scene.time.now;
        s.colgando = { desde: ahora, sinAnclaHasta: ahora + VENTANA_ANCLAR, avisado: false };
        s.body.setAllowGravity(false);
        s.setVelocity(0, 0);
        scene.cameras.main.shake(150, 0.004);
        scene.sound.play('romper', { volume: 0.4, rate: 1.6 });
        scene.mostrarMensajeCorto?.('¡SOSTÉNLO!\n¡ANCLATE! (↓ / S)');
        if (enLinea()) enviarEvento('colgando', {});
    }
    return true;
}

function actualizarColgado(scene, s, nodos) {
    if (!s.colgando) return;
    const ahora = scene.time.now;
    // quién lo sostiene: el compañero anclado más cercano
    const anclas = nodos.filter(n => n.anclado && n.s !== s);
    const ancla = anclas.sort((p, q) => Math.abs(p.cx - s.x) - Math.abs(q.cx - s.x))[0];
    if (ancla) s.colgando.sinAnclaHasta = ahora + GRACIA_ANCLA;

    // nadie lo sostuvo a tiempo (o se trabó demasiado): ahora sí es una caída
    if (ahora > s.colgando.sinAnclaHasta || ahora - s.colgando.desde > RESCATE_MAX) {
        s.colgando = null;
        s.rescateAgotado = true;
        s.body.setAllowGravity(true);
        s.clearTint();
        scene.morirPorCaida?.();
        return;
    }
    // ya está a salvo: parado en el suelo, o ya por encima del borde y con suelo firme debajo
    if ((enSuelo(s) && s.y < Y_COLGANDO - 4) || (s.body.bottom <= SUELO_Y && haySueloDebajo(scene, s))) {
        s.colgando = null;
        s.body.setAllowGravity(true);
        s.clearTint();
        scene.sound.play('punto_control', { volume: 0.5, rate: 1.2 });
        scene.mostrarMensajeCorto?.('¡RESCATADO!');
        return;
    }
    // cuelga sobre la lava (parpadea) y, si alguien lo sostiene, la cadena lo sube hacia él
    if (s.y > Y_COLGANDO) s.y = Y_COLGANDO;
    s.setTint(Math.floor(ahora / 120) % 2 ? 0xff8a5a : 0xffffff);
    if (ancla) {
        const dx = ancla.cx - s.body.center.x, dy = ancla.cy - s.body.center.y;
        // primero sale del foso (hasta el nivel del suelo) y después va hacia el que lo sostiene
        const enElFoso = s.body.bottom > SUELO_Y - 2;
        s.setVelocity(Phaser.Math.Clamp(dx * 4, -SUBE, SUBE), dy < -6 || enElFoso ? -SUBE : 0);
    } else {
        s.setVelocity(s.body.velocity.x * 0.5, 0);
    }
}

// hay suelo firme justo debajo del cuerpo (no lava ni suelo falso)
function haySueloDebajo(scene, s) {
    const b = s.body;
    return scene.floor.getChildren().some(p => p.body?.enable && !p.esFalso && b.center.x > p.body.left && b.center.x < p.body.right &&
        p.body.top >= b.bottom - 2 && p.body.top <= b.bottom + 30);
}

// cadena activa en este nivel (para mostrar el botón de anclar en el celular)
export const hayCadena = scene => !!(scene.compa?.active || scene.cadenaRed);

// un jugador de la fila: los locales tienen cuerpo de física; los remotos, lo que mandó la red
function nodo(n) {
    if (!n.local) return n;
    const s = n.s, b = s.body;
    return { local: true, s, cx: b.center.x, cy: b.center.y, v: b.velocity, suelo: enSuelo(s), anclado: !!s.anclado };
}

function moverCompa(scene, c) {
    const k = scene.teclasCompa, pj = c.pj, suelo = enSuelo(c);
    // colgado de una argolla: se mueve con la argolla (mecanismos.js)
    if (c.enArgolla) { c.anims.play(`${pj.anim}-jump`, true); return; }
    const v = pj.velocidad;
    c.anclado = k.anclar.isDown && suelo;
    if (c.anclado) {
        c.setVelocityX(0);
    } else if (k.izq.isDown) {
        c.setVelocityX(-VEL_CARRERA * v);
        c.flipX = true;
    } else if (k.der.isDown) {
        c.setVelocityX(VEL_CARRERA * v);
        c.flipX = false;
    } else if (suelo) {
        c.setVelocityX(0);
    } else if (Math.abs(c.body.velocity.x) > VEL_DERIVA * v) {
        c.setVelocityX(Math.sign(c.body.velocity.x) * VEL_DERIVA * v);
    }

    const JD = Phaser.Input.Keyboard.JustDown;
    if (suelo) c.saltosAire = 0;
    if (JD(k.salto) && !c.anclado) {
        if (suelo) {
            c.setVelocityY(-pj.salto);
            scene.sound.play('salto', { volume: 0.25, rate: 1.1 });
        } else if (pj.dobleSalto && (c.saltosAire || 0) < 1) {
            c.saltosAire = (c.saltosAire || 0) + 1;
            c.setVelocityY(Math.min(c.body.velocity.y - 120, -440));
            scene.sound.play('salto', { volume: 0.25, rate: 1.35 });
        }
    }

    const anim = !suelo ? 'jump' : c.anclado ? 'idle' : Math.abs(c.body.velocity.x) > 5 ? 'run' : 'idle';
    c.anims.play(`${pj.id}-${anim}`, true);
    c.setTint(c.anclado ? 0x9fd8ff : 0xffffff);
}

// el jugador 1 se ancla con ↓ (en el suelo): no se mueve mientras lo mantiene
function anclarJugador1(scene, a) {
    a.anclado = scene.keys.down.isDown && enSuelo(a);
    if (a.anclado) a.setVelocityX(0);
    if (a.anclado) a.setTint(0x9fd8ff);
    else if (a.tintTopLeft === 0x9fd8ff) a.clearTint();
}

// la cadena solo actúa cuando está tensa
function tensar(a, c) {
    const dx = c.cx - a.cx, dy = c.cy - a.cy;
    const dist = Math.hypot(dx, dy);
    // con alguien de otra pantalla, un poco de holgura: así el retraso de la red no da tirones
    const largo = a.local && c.local ? LARGO : LARGO + HOLGURA_RED;
    if (dist <= largo || dist === 0) return;
    // con un jugador de otra pantalla, una distancia enorme es un dato atrasado (acaba de reaparecer
    // o entrar a la arena): no se tira hasta que llegue su posición nueva
    if (dist > LARGO * 4 && !(a.local && c.local)) return;
    const nx = dx / dist, ny = dy / dist;

    // cuánto absorbe cada uno del tirón (0 = no se mueve, 1 = se lleva todo);
    // las reglas son simétricas: cada pantalla calcula lo mismo y aplica solo su parte
    let wa = 0.5, wc = 0.5;
    if (a.anclado && !c.anclado) { wa = 0; wc = 1; }
    else if (c.anclado && !a.anclado) { wa = 1; wc = 0; }
    else if (a.anclado && c.anclado) { wa = 0; wc = 0; }
    else if (a.suelo && !c.suelo) { wa = 0; wc = 1; arrastrar(a, dx); }
    else if (c.suelo && !a.suelo) { wa = 1; wc = 0; arrastrar(c, -dx); }

    const va = a.v, vc = c.v;
    // velocidad con la que se separan: esa se anula (la cadena no se estira). Nada más: si además se
    // empuja hacia el otro, la cadena hace de resorte (sale disparado, se pasa y rebota)
    const separan = (vc.x - va.x) * nx + (vc.y - va.y) * ny;
    if (separan > 0) {
        if (a.local) { va.x += nx * separan * wa; va.y += ny * separan * wa; }
        if (c.local) { vc.x -= nx * separan * wc; vc.y -= ny * separan * wc; }
    }

    // lo que ya se estiró se corrige acomodando la posición (de a poco; de golpe si es mucho)
    const estiron = dist - largo;
    const corregir = estiron > ESTIRON_MAX ? estiron - ESTIRON_MAX + ESTIRON_MAX * CORRECCION : estiron * CORRECCION;
    if (a.local && wa > 0) { a.s.x += nx * corregir * wa; a.s.y += ny * corregir * wa; }
    if (c.local && wc > 0) { c.s.x -= nx * corregir * wc; c.s.y -= ny * corregir * wc; }
}

// el del suelo es arrastrado hacia el que cuelga (si camina en contra, el que cuelga sube)
function arrastrar(n, haciaX) {
    if (n.local) n.v.x += Math.sign(haciaX) * ARRASTRE;
}

// eslabones a lo largo de una curva entre cada par: floja cuelga, tensa queda recta
function dibujar(g, nodos, time) {
    g.clear();
    for (let k = 0; k + 1 < nodos.length; k++) {
        const x0 = nodos[k].cx, y0 = nodos[k].cy - 6, x1 = nodos[k + 1].cx, y1 = nodos[k + 1].cy - 6;
        const dist = Math.hypot(x1 - x0, y1 - y0);
        const comba = dist < LARGO ? Math.sqrt(LARGO * LARGO - dist * dist) * 0.5 : 0;
        const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2 + comba;
        const tensa = dist > LARGO + 4;
        g.lineStyle(2, tensa ? 0xc9a090 : 0x9aa0aa, 1);
        for (let i = 0; i <= ESLABONES; i++) {
            const t = i / ESLABONES, u = 1 - t;
            const x = u * u * x0 + 2 * u * t * cx + t * t * x1;
            const y = u * u * y0 + 2 * u * t * cy + t * t * y1;
            // tensa: tiembla un poco y se pone rojiza
            const temblor = tensa ? Math.sin(time * 0.05 + i + k * 7) * 0.8 : 0;
            if (i % 2) g.strokeEllipse(x, y + temblor, 6, 4);
            else g.strokeEllipse(x, y + temblor, 4, 6);
        }
    }
}
