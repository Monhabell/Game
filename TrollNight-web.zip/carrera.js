// Carrera en línea: todos corren la MISMA pista (pistas.js) y el primero en llegar a la meta gana.
//
// Cómo se juega:
//   - En la sala (sala.js) cada uno elige SU apuesta (0, 10, 25, 50 o 100) y confirma "Listo"; el
//     anfitrión elige la pista y arranca cuando todos están listos. De 2 a 8 jugadores.
//   - Cada uno corre en su pantalla, con sus enemigos y sus trampas (la misma semilla para todos, así
//     el recorrido es igual y justo). Los rivales se ven como fantasmas: no estorban ni activan trampas.
//   - PODERES: los poderes especiales de un rival sí te alcanzan (poderes.js revisa en TU pantalla si
//     el poder que lanzó su fantasma te tocó). Nunca quitan vidas: empujan, aturden, congelan o
//     atraen un momento (recibirPoderCarrera). Después de un golpe hay 1,5 s de protección (nada de
//     encadenar golpes) y un escudo activo lo para. Quien te alcanzó se entera ('carreraGolpe').
//   - Pistas con zonas (las Ruinas del Abismo): al entrar a cada zona se anuncia su nombre y el aviso
//     de "lo que viene" muestra la zona siguiente.
//   - HUD: arriba a la izquierda las posiciones, al centro el cronómetro y el avance de cada uno (para
//     ver cómo lo pasa el rival), a la derecha el premio. En el escenario, lo que viene (lava,
//     bifurcación, meta) con su distancia, y un letrero sobre la meta.
//   - Al terminar: podio (2º, 1º, 3º), ganador, tiempo, premio de cada uno y "Volver a competir"
//     (lo arranca el anfitrión; los demás le avisan que quieren otra).
//   - Morir no saca de la carrera: se vuelve al último punto de control (y se pierde tiempo).
//   - Salida a la vez: desde que llega 'empezar' hay una cuenta regresiva fija (aunque cada celular
//     cargue la pista a su ritmo, todos salen en el mismo momento): 3, 2, 1… ¡CORRAN! en grande y la
//     puerta de salida se abre.
//   - Apuestas: cada uno paga la suya al salir. El ganador recupera la suya y cada rival le paga lo
//     que apostó el ganador (o lo que apostó el rival, si es menos); al rival se le devuelve lo que
//     sobra. Así apostar nada no te deja ganar el pozo de los demás. Si nadie apostó: 30 monedas al
//     ganador y 10 a los demás.
//
// En red (sin lógica nueva en el servidor, solo el modo 'carrera'):
//   - Quien llega avisa 'carreraMeta' con su tiempo. El ANFITRIÓN junta las llegadas un instante y
//     anuncia 'carreraFin' con el ganador (el de menor tiempo) y el orden de todos.
//   - Si todos los rivales se van de la sala, el que queda gana.
//
// api (la da game.js): { mensaje(scene, texto, ms), premio(monedas), pagar(monedas), salir(),
//   volverASala(), revancha(nivel) }

import { red, alRecibir, enviarEvento, esAnfitrion, informarSaldo } from "./red.js"
import { PERSONAJES } from "./personajes.js"
import { APUESTAS } from "./arena.js"
import { saldo } from "./tienda.js"
import { SUELO_Y } from "./niveles.js"
import { pistaDe } from "./pistas.js"

const CUENTA_MS = 4000;      // de 'empezar' a la salida
const ESPERA_LLEGADAS = 400; // el anfitrión espera este rato por si otro llegó casi a la vez
const PREMIO_GANADOR = 30, PREMIO_CONSUELO = 10; // sin apuesta
const HUD_MS = 100;          // cada cuánto se repinta el HUD (cronómetro, posiciones, avisos)

let carrera = null, api = null, juego = null;
export const carreraActiva = () => carrera;
export const esModoCarrera = modo => modo === 'carrera';
const escena = () => (juego?.scene.isActive('juego') ? juego.scene.getScene('juego') : null);
const nombreDe = id => (id === red.tuId ? 'Tú' : red.jugadores.find(j => j.id === id)?.nombre || carrera?.nombres.get(id) || 'Alguien');
const colorDe = id => {
    const j = red.jugadores.find(x => x.id === id);
    const pj = PERSONAJES.find(p => p.id === j?.pj) || PERSONAJES[0];
    return '#' + pj.color.toString(16).padStart(6, '0');
};

export function iniciarCarrera(juegoPhaser, ganchos) {
    juego = juegoPhaser;
    api = ganchos;
    alRecibir('evento', m => {
        if (!carrera) return;
        if (m.tipo === 'carreraMeta') llegada(m.de, Number(m.ms));
        else if (m.tipo === 'carreraFin') terminar(m);
        else if (m.tipo === 'carreraOtra' && carrera.fin && esAnfitrion()) { (carrera.piden ||= new Set()).add(m.de); pintarPiden(); }
        else if (m.tipo === 'carreraGolpe' && m.para === red.tuId) avisarGolpe(m);
    });
    // se fueron todos los rivales: el que queda gana (lo anuncia él mismo, ya es el anfitrión)
    alRecibir('sala', () => {
        if (carrera && !carrera.fin && esAnfitrion() && red.jugadores.length === 1) anunciar(red.tuId, null);
    });
}

// el anfitrión empezó la carrera: cada uno paga SU apuesta al salir
export function empezarCarrera({ pista, jugadores }) {
    cerrarFin();
    const apuestas = new Map(jugadores.map(j => [j.id, APUESTAS.includes(Number(j.apuesta)) ? Number(j.apuesta) : 0]));
    const mia = apuestas.get(red.tuId) || 0;
    if (mia) api.pagar(mia);
    carrera = {
        pista,
        nombrePista: pistaDe(pista).nombre.toUpperCase(),
        apuestas,
        nombres: new Map(jugadores.map(j => [j.id, j.nombre])), // (por si alguien se va antes del final)
        salida: Date.now() + CUENTA_MS,
        avance: new Map(),   // id -> fracción del recorrido (0 a 1)
        llegadas: new Map(), // (anfitrión) id -> ms que tardó
        fin: null,
    };
    crearHud(jugadores);
}
export const terminarCarrera = () => { carrera = null; cerrarFin(); quitarHud(); cuentaEl?.remove(); cuentaEl = null; };

// ---------- en el nivel ----------
// al crear la escena (también al reaparecer después de morir)
export function prepararCarrera(scene, nivel, inicioX) {
    scene.carrera = carrera;
    carrera.meta = nivel.meta;
    carrera.inicioX ??= inicioX;
    carrera.peligros ??= peligrosDe(nivel);
    carrera.zonas ??= nivel.zonas?.length ? [...nivel.zonas].sort((a, b) => a[0] - b[0]) : null;
    letreroMeta(scene, nivel.meta);
    if (carrera.fin) { scene.cinematica = true; return; }
    const falta = carrera.salida - Date.now();
    if (falta <= 0) return;
    // cuenta regresiva: quietos detrás de la puerta hasta la salida
    scene.cinematica = true;
    const puerta = crearPuerta(scene, inicioX + 70);
    api.mensaje(scene, carrera.nombrePista || 'CARRERA', Math.max(300, falta - 3200));
    const pasos = Math.min(3, Math.ceil(falta / 1000));
    for (let i = pasos; i >= 1; i--) {
        scene.time.delayedCall(falta - i * 1000, () => {
            cuenta(String(i));
            scene.sound.play('menu_mover', { volume: 0.7 });
        });
    }
    scene.time.delayedCall(falta, () => {
        if (!carrera || carrera.fin) return;
        scene.cinematica = false;
        cuenta('¡CORRAN!', true);
        puerta.abrir();
        scene.sound.play('menu_ok', { volume: 0.7 });
        scene.cameras.main.shake(180, 0.004);
    });
}

// cada fotograma (también muerto o en la cuenta regresiva): el HUD
export function actualizarCarrera(scene) {
    if (!scene.carrera || !carrera) return;
    const ahora = performance.now();
    if (ahora < (carrera.proxHud || 0)) return;
    carrera.proxHud = ahora + HUD_MS;
    const recorrido = Math.max(1, carrera.meta - carrera.inicioX);
    const fraccion = x => Math.min(1, Math.max(0, (x - carrera.inicioX) / recorrido));
    if (!scene.mascotaGesi.isDead) carrera.avance.set(red.tuId, fraccion(scene.mascotaGesi.x));
    scene.remotos?.forEach((r, id) => { if (r.estado && !r.estado.muerto) carrera.avance.set(id, fraccion(r.estado.x)); });
    if (carrera.fin) carrera.avance.set(carrera.fin.ganador, 1);
    anunciarZona(scene);
    pintarHud(scene);
}

// pistas con zonas: al entrar a una zona nueva, su nombre en grande (una vez por carrera)
function anunciarZona(scene) {
    const zonas = carrera.zonas;
    const g = scene.mascotaGesi;
    if (!zonas?.length || carrera.fin || carrera.llegue || g.isDead) return;
    let i = -1;
    zonas.forEach(([x], k) => { if (g.x >= x) i = k; });
    if (i <= (carrera.zonaVista ?? 0)) return; // (la primera la anuncia la salida)
    carrera.zonaVista = i;
    api.mensaje(scene, `ZONA ${i + 1}\n${zonas[i][1]}`, 1600);
}

// ---------- poderes entre rivales ----------
const PROTEGIDO_MS = 1500;  // después de un golpe de rival, un rato sin recibir otro
const QUIETO_MAX = 1100;    // ms máximos sin poder moverse por un golpe
const CONGELA_MAX = 1500;   // ms máximos congelado (contra jugadores, congelar dura la mitad)

// el poder de un rival me alcanzó (lo decidió mi pantalla, ver poderes.js): nunca quita vidas
export function recibirPoderCarrera(scene, p, de, ox) {
    const g = scene.mascotaGesi;
    if (!carrera || carrera.fin || carrera.llegue || scene.cinematica || g.isDead || scene.nivelTerminado) return;
    const ahora = scene.time.now;
    if (ahora < (scene.protegidoCarrera || 0)) return;
    scene.protegidoCarrera = ahora + PROTEGIDO_MS;
    const quien = nombreDe(de).toUpperCase();
    // un escudo activo (habilidad o poder de escudo) lo para
    if (ahora < (scene.escudoHasta || 0)) {
        api.mensaje(scene, '¡BLOQUEADO!', 700);
        enviarEvento('carreraGolpe', { para: de, bloqueado: 1 });
        return;
    }
    const congela = p.tipo === 'tiempo' ? Math.min(2000, (p.duracion || 0) / 2) : Math.min(CONGELA_MAX, (p.congela || 0) / 2);
    const aturde = Math.min(QUIETO_MAX, p.aturde || 0);
    const quieto = Math.max(congela, aturde, Math.min(QUIETO_MAX, 250 + 120 * (p.daño || 0)));
    // empujón hacia el lado contrario de donde vino (el tiempo detenido y el vórtice no empujan)
    let empuje = 0;
    if (p.tipo !== 'tiempo' && p.tipo !== 'iman') {
        const lado = Math.sign(g.body.center.x - ox) || 1;
        const fuerza = Math.min(320, p.empuje || 160 + 30 * (p.daño || 0));
        g.setVelocity(lado * fuerza, -180);
        empuje = 220;
        scene.empujadoHasta = ahora + empuje;
    }
    scene.aturdidoHasta = ahora + empuje + quieto;
    // se ve: congelado (celeste) o aturdido (amarillo), y parpadea mientras está protegido
    g.setTint(congela ? 0x9fe8ff : 0xffe066);
    scene.time.delayedCall(empuje + quieto, () => g.active && !g.isDead && g.clearTint());
    scene.tweens.add({ targets: g, alpha: 0.55, yoyo: true, repeat: Math.floor(PROTEGIDO_MS / 240), duration: 120, onComplete: () => g.setAlpha(1) });
    scene.cameras.main.shake(140, 0.005);
    scene.sound.play('bump', { volume: 0.6 });
    api.mensaje(scene, congela ? `¡${quien} TE CONGELÓ!` : p.tipo === 'iman' ? `¡${quien} TE ATRAPÓ!` : `¡${quien} TE ALCANZÓ!`, 900);
    enviarEvento('carreraGolpe', { para: de, poder: p.nombre });
}

// yo alcancé a un rival con un poder (me avisa él)
function avisarGolpe(m) {
    const scene = escena();
    if (!scene || carrera.fin) return;
    const quien = nombreDe(m.de).toUpperCase();
    api.mensaje(scene, m.bloqueado ? `${quien} BLOQUEÓ TU PODER` : `¡LE DISTE A ${quien}!`, 800);
}

// llegué a la meta (game.js ya hizo la fiesta del faro)
export function llegarMetaCarrera(scene) {
    if (!carrera || carrera.fin || carrera.llegue) return;
    carrera.llegue = true;
    const ms = Math.max(0, Date.now() - carrera.salida);
    carrera.miTiempo = ms; // (el cronómetro se detiene)
    carrera.avance.set(red.tuId, 1);
    enviarEvento('carreraMeta', { ms });
    llegada(red.tuId, ms);
    api.mensaje(scene, '¡LLEGASTE!', 1500);
}

// (anfitrión) alguien llegó: se espera un instante por si otro llegó casi a la vez y gana el más rápido
function llegada(id, ms) {
    if (!carrera || carrera.fin || !esAnfitrion() || !(ms >= 0)) return;
    if (!carrera.llegadas.has(id)) carrera.llegadas.set(id, ms);
    if (carrera.decidiendo) return;
    carrera.decidiendo = true;
    setTimeout(() => {
        if (!carrera || carrera.fin) return;
        const [ganador, tiempo] = [...carrera.llegadas.entries()].sort((a, b) => a[1] - b[1])[0];
        anunciar(ganador, tiempo);
    }, ESPERA_LLEGADAS);
}

function anunciar(ganador, ms) {
    // el orden: el ganador y después los demás según cuánto avanzaron
    const resto = red.jugadores.map(j => j.id).filter(id => id !== ganador)
        .sort((a, b) => (carrera.avance.get(b) || 0) - (carrera.avance.get(a) || 0));
    const m = { ganador, ms, orden: [ganador, ...resto] };
    enviarEvento('carreraFin', m);
    terminar(m);
}

// fin de la carrera: premios y pantalla del podio
function terminar(m) {
    if (!carrera || carrera.fin) return;
    carrera.fin = m;
    const mio = m.ganador === red.tuId;
    const pagos = calcularPagos(m.ganador);
    const premio = pagos.get(red.tuId) || 0;
    if (premio) api.premio(premio);
    informarSaldo(saldo()); // (para la próxima: la sala revisa que alcance para la apuesta)
    const scene = escena();
    if (scene) {
        scene.cinematica = true;
        if (!mio) {
            api.mensaje(scene, `¡GANÓ ${nombreDe(m.ganador).toUpperCase()}!`, 1800);
            scene.sound.play('gameover', { volume: 0.5 });
        }
    }
    pintarHud(scene);
    setTimeout(() => {
        if (carrera?.fin !== m) return;
        mostrarFin({
            mio,
            orden: (Array.isArray(m.orden) ? m.orden : [m.ganador]).map(Number),
            ms: Number(m.ms),
            pagos,
        });
    }, mio ? 1800 : 2200);
}

// cuánto recibe cada uno al final (lo que ya pagó al salir no cuenta aquí)
function calcularPagos(ganador) {
    const pagos = new Map();
    const a = carrera.apuestas;
    const total = [...a.values()].reduce((t, v) => t + v, 0);
    if (!total) {
        a.forEach((_v, id) => pagos.set(id, id === ganador ? PREMIO_GANADOR : PREMIO_CONSUELO));
        return pagos;
    }
    const delGanador = a.get(ganador) || 0;
    let gana = delGanador;
    a.forEach((v, id) => {
        if (id === ganador) return;
        const pierde = Math.min(v, delGanador);
        gana += pierde;
        pagos.set(id, v - pierde); // lo que sobra se le devuelve
    });
    pagos.set(ganador, gana);
    return pagos;
}

// ---------- salida: cuenta regresiva gigante y la puerta ----------
let cuentaEl = null;
function cuenta(texto, final = false) {
    cuentaEl?.remove();
    cuentaEl = document.createElement('div');
    cuentaEl.className = `carrera-cuenta${final ? ' ya' : ''}`;
    cuentaEl.setAttribute('aria-live', 'assertive');
    cuentaEl.textContent = texto;
    document.getElementById('game').append(cuentaEl);
    const el = cuentaEl;
    setTimeout(() => { el.remove(); if (cuentaEl === el) cuentaEl = null; }, final ? 1100 : 900);
}

// puerta de salida: una reja de piedra delante de todos que sube al "¡CORRAN!"
function crearPuerta(scene, x) {
    const alto = 150;
    const textura = scene.textures.exists('mz_bloque') ? 'mz_bloque' : '__WHITE';
    const puerta = scene.add.image(x, SUELO_Y, textura).setOrigin(0.5, 1).setDisplaySize(26, alto).setTint(0x8a8fa8).setDepth(34);
    const marco = scene.add.rectangle(x, SUELO_Y - alto - 3, 46, 8, 0x3a3f55).setDepth(35);
    const luz = scene.add.circle(x, SUELO_Y - alto - 14, 6, 0xff5a5a).setDepth(35);
    return {
        abrir: () => {
            luz.setFillStyle(0x4fd1a5);
            scene.tweens.add({ targets: puerta, y: SUELO_Y - alto, alpha: 0.2, duration: 450, ease: 'Quad.in', onComplete: () => puerta.destroy() });
            scene.tweens.add({ targets: [marco, luz], alpha: 0, delay: 900, duration: 400, onComplete: () => { marco.destroy(); luz.destroy(); } });
        },
    };
}

// ---------- HUD de la carrera (capa HTML sobre el juego) ----------
//   arriba a la izquierda: posiciones · arriba al centro: cronómetro y avance · arriba a la derecha: premio
//   en el escenario: lo que viene (lava, bifurcación, meta) con su distancia
let hud = null;
const PX_POR_METRO = 32;     // un bloque = un metro
const AVISO_DESDE = 1400;    // px: el aviso de lo que viene aparece a esta distancia
const tiempo = ms => `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}.${Math.floor(ms % 1000 / 100)}`;

function crearHud(jugadores) {
    quitarHud();
    hud = document.createElement('div');
    hud.className = 'carrera-hud';
    hud.innerHTML = `
        <ol class="carrera-posiciones" data-posiciones aria-label="Posiciones"></ol>
        <div class="carrera-centro">
            <span class="carrera-reloj" data-reloj>0:00.0</span>
            <div class="carrera-pista" aria-hidden="true">
                <span class="carrera-meta">🏁</span>
                ${jugadores.map(j => `<span class="carrera-punto ${j.id === red.tuId ? 'yo' : ''}" data-id="${j.id}" style="--c:${colorDe(j.id)}"></span>`).join('')}
            </div>
        </div>
        <div class="carrera-pozo" data-pozo></div>
        <div class="carrera-aviso" data-aviso hidden></div>`;
    document.getElementById('game').append(hud);
    pintarPozo();
}
function quitarHud() {
    hud?.remove();
    hud = null;
}

// premio acumulado: lo apostado entre todos y lo que ganarías tú
function pintarPozo() {
    const caja = hud?.querySelector('[data-pozo]');
    if (!caja) return;
    const a = carrera.apuestas;
    const total = [...a.values()].reduce((t, v) => t + v, 0);
    const mia = a.get(red.tuId) || 0;
    const siGanas = [...a.entries()].reduce((t, [id, v]) => t + (id === red.tuId ? 0 : Math.min(v, mia)), 0);
    caja.innerHTML = total
        ? `<span>🏆 Pozo</span><b>◉ ${total}</b><small>${mia ? `si ganas: +${siGanas}` : 'no apostaste'}</small>`
        : `<span>🏆 Premio</span><b>◉ ${PREMIO_GANADOR}</b><small>al ganador</small>`;
}

function pintarHud(scene) {
    if (!hud || !carrera) return;
    const enCarrera = new Set(red.jugadores.map(j => j.id));
    // avance de cada uno en la pista de arriba
    hud.querySelectorAll('[data-id]').forEach(p => {
        const id = Number(p.dataset.id);
        p.hidden = !enCarrera.has(id);
        p.style.left = `${(carrera.avance.get(id) || 0) * 100}%`;
    });
    // posiciones: el ganador primero y después por avance
    const orden = [...enCarrera].sort((x, y) => (y === carrera.fin?.ganador) - (x === carrera.fin?.ganador)
        || (carrera.avance.get(y) || 0) - (carrera.avance.get(x) || 0));
    // con muchos jugadores: los 4 primeros y tú
    const visibles = orden.filter((id, i) => i < 4 || id === red.tuId);
    hud.querySelector('[data-posiciones]').innerHTML = visibles.map(id => {
        const i = orden.indexOf(id);
        const llego = id === carrera.fin?.ganador || (id === red.tuId && carrera.llegue);
        return `<li class="${id === red.tuId ? 'yo' : ''}" style="--c:${colorDe(id)}"><span class="carrera-n">${i + 1}</span>
            <span class="carrera-nombre">${escapar(nombreDe(id))}</span>${llego ? ' 🏁' : ''}</li>`;
    }).join('');
    // cronómetro: corre desde la salida; se detiene al llegar (tú) o al terminar (el del ganador)
    const ms = carrera.fin && Number(carrera.fin.ms) >= 0 ? Number(carrera.fin.ms)
        : carrera.miTiempo ?? Math.max(0, Date.now() - carrera.salida);
    hud.querySelector('[data-reloj]').textContent = tiempo(ms);
    // lo que viene en el escenario
    const aviso = hud.querySelector('[data-aviso]');
    const g = scene?.mascotaGesi;
    const proximo = g && !carrera.fin && carrera.peligros?.find(p => p.x > g.x);
    const dist = proximo ? proximo.x - g.x : Infinity;
    aviso.hidden = !(dist < AVISO_DESDE || proximo?.tipo === 'meta');
    if (!aviso.hidden) {
        aviso.className = `carrera-aviso ${proximo.tipo}`;
        aviso.textContent = `${proximo.texto} · ${Math.max(0, Math.round(dist / PX_POR_METRO))} m →`;
    }
}

// lo que viene en la pista: fosos de lava, bifurcaciones y la meta (las trampas ocultas, no: son ocultas)
function peligrosDe(nivel) {
    // pista con zonas: se avisa la zona que viene, las bifurcaciones y la meta
    if (nivel.zonas?.length) {
        return [
            ...nivel.zonas.filter(([x]) => x > 0).map(([x, nombre]) => ({ x, tipo: 'zona', texto: `⚑ ${nombre.charAt(0)}${nombre.slice(1).toLowerCase()}` })),
            ...(nivel.atajos || []).map(([a]) => ({ x: a - 330, tipo: 'bifurcacion', texto: '⑂ Bifurcación' })),
            { x: nivel.meta, tipo: 'meta', texto: '🏁 Meta' },
        ].sort((p, q) => p.x - q.x);
    }
    const lista = [
        ...(nivel.lava || []).filter(([a, b]) => b - a >= 100).map(([a]) => ({ x: a, tipo: 'lava', texto: '🔥 Lava' })),
        // (la bifurcación empieza ~330 px antes de su atajo: donde está el primer escalón)
        ...(nivel.atajos || []).map(([a]) => ({ x: a - 330, tipo: 'bifurcacion', texto: '⑂ Bifurcación' })),
        { x: nivel.meta, tipo: 'meta', texto: '🏁 Meta' },
    ].sort((p, q) => p.x - q.x);
    // dos avisos casi juntos se dicen como uno
    return lista.filter((p, i) => i === 0 || p.x - lista[i - 1].x > 250 || p.tipo === 'meta');
}

// la meta, bien visible en el escenario: un letrero que flota sobre el faro
function letreroMeta(scene, x) {
    const t = scene.add.text(x, SUELO_Y - 250, '🏁 META 🏁', {
        fontFamily: '"Press Start 2P", monospace', fontSize: '16px', color: '#ffe066', stroke: '#000', strokeThickness: 6,
    }).setOrigin(0.5).setDepth(41);
    scene.tweens.add({ targets: t, y: t.y - 8, yoyo: true, repeat: -1, duration: 700, ease: 'Sine.inOut' });
}

// ---------- pantalla final: podio, ganador, premio y volver a competir ----------
let capaFin = null;
const MEDALLAS = ['🥇', '🥈', '🥉'];
function mostrarFin(d) {
    cerrarFin();
    const anfitrion = esAnfitrion();
    const conApuestas = [...carrera.apuestas.values()].some(v => v > 0);
    const neto = id => (d.pagos.get(id) || 0) - (conApuestas ? carrera.apuestas.get(id) || 0 : 0);
    const signo = n => `${n >= 0 ? '+' : '−'}${Math.abs(n)}`;
    // podio: 2º, 1º, 3º (como uno de verdad)
    const escalon = i => {
        const id = d.orden[i];
        if (id == null) return '<div class="carrera-escalon vacio"></div>';
        return `<div class="carrera-escalon e${i + 1} ${id === red.tuId ? 'yo' : ''}" style="--c:${colorDe(id)}">
            <span class="carrera-medalla" aria-hidden="true">${MEDALLAS[i]}</span>
            <b>${escapar(nombreDe(id))}</b>
            <small>◉ ${signo(neto(id))}</small>
            <div class="carrera-bloque">${i + 1}</div>
        </div>`;
    };
    const resto = d.orden.slice(3).map((id, k) => `<li${id === red.tuId ? ' class="yo"' : ''}>${k + 4}º <b>${escapar(nombreDe(id))}</b>
        <small>(${Math.round((carrera.avance.get(id) || 0) * 100)}% · ◉ ${signo(neto(id))})</small></li>`).join('');
    const mioNeto = neto(red.tuId);
    const premio = d.mio ? `Premio recibido: ◉ +${d.pagos.get(red.tuId) || 0}`
        : mioNeto > 0 ? `Recibes ◉ +${mioNeto}`
        : mioNeto < 0 ? `Perdiste ◉ ${-mioNeto}${(d.pagos.get(red.tuId) || 0) ? ` (se te devuelven ◉ ${d.pagos.get(red.tuId)})` : ''}`
        : 'No ganas ni pierdes monedas';
    capaFin = document.createElement('div');
    capaFin.className = 'menu-capa';
    capaFin.innerHTML = `
        <div class="menu-panel arena-fin carrera-fin ${d.mio ? 'gano' : ''}" role="dialog" aria-modal="true" aria-labelledby="carrera-fin-titulo">
            <h2 id="carrera-fin-titulo">${d.mio ? '🏆 ¡GANASTE!' : `🏆 ¡GANÓ ${escapar(nombreDe(d.orden[0])).toUpperCase()}!`}</h2>
            <p class="carrera-fin-tiempo">${d.ms >= 0 ? `Tiempo: ${tiempo(d.ms)}` : 'Los demás se fueron'}</p>
            <div class="carrera-podio3">${escalon(1)}${escalon(0)}${escalon(2)}</div>
            ${resto ? `<ol class="arena-medallas carrera-podio">${resto}</ol>` : ''}
            <p class="carrera-premio ${mioNeto < 0 ? 'pierde' : ''}">${premio}</p>
            <p class="menu-nota" data-piden hidden></p>
            <button type="button" class="menu-boton sala-empezar" data-fin="revancha">↻ Volver a competir</button>
            ${anfitrion ? '<button type="button" class="menu-boton" data-fin="sala">☰ Volver a la sala</button>' : ''}
            <button type="button" class="menu-boton menu-salir" data-fin="salir">✕ Salir</button>
        </div>`;
    document.getElementById('game').append(capaFin);
    const pista = carrera.pista;
    capaFin.addEventListener('click', e => {
        const b = e.target.closest('[data-fin]');
        const accion = b?.dataset.fin;
        if (!accion) return;
        if (accion === 'revancha' && !esAnfitrion()) {
            // solo el anfitrión arranca: los demás le avisan que quieren otra
            enviarEvento('carreraOtra', {});
            b.disabled = true;
            b.textContent = 'Esperando al anfitrión…';
            return;
        }
        cerrarFin();
        if (accion === 'revancha') api.revancha(pista);
        else if (accion === 'sala') api.volverASala();
        else api.salir();
    });
    capaFin.addEventListener('keydown', e => e.stopPropagation());
    capaFin.querySelector('[data-fin]')?.focus();
    pintarPiden();
}
// (anfitrión) quiénes quieren volver a competir
function pintarPiden() {
    const p = capaFin?.querySelector('[data-piden]');
    if (!p || !carrera?.piden?.size) return;
    p.hidden = false;
    p.textContent = `🙋 ${[...carrera.piden].map(nombreDe).join(', ')} ${carrera.piden.size > 1 ? 'quieren' : 'quiere'} volver a competir`;
}
export function cerrarFin() {
    capaFin?.remove();
    capaFin = null;
}

const escapar = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
